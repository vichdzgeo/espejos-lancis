#relocator
With this plugin you can collect all the local files of your current qgis project (must be saved prior) into a consolidated directory and also creates and adjusted copy of your qgs project file with adjusted pathes in this directory.
Furthermoe you can choose to create a zip-file with the whole project as well.

##Abilities
The current setup will support local vector and raster files as well as WMS services.

